-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Dec 27, 2025 at 01:38 PM
-- Server version: 8.0.34-26-beget-1-1
-- PHP Version: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pavels3f_fball`
--

-- --------------------------------------------------------

--
-- Table structure for table `players`
--
-- Creation: Dec 10, 2025 at 11:52 AM
-- Last update: Dec 26, 2025 at 08:20 PM
--

DROP TABLE IF EXISTS `players`;
CREATE TABLE `players` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `username` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `goals` int DEFAULT '0',
  `gamesPlayed` int DEFAULT '0',
  `wins` int DEFAULT '0',
  `draws` int DEFAULT '0',
  `losses` int DEFAULT '0',
  `rating` decimal(5,2) DEFAULT '0.00',
  `photo` varchar(255) COLLATE utf8mb4_general_ci DEFAULT 'default.jpg',
  `assists` int DEFAULT '0',
  `saves` int DEFAULT '0',
  `mvp` int DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `players`
--

INSERT INTO `players` (`id`, `name`, `username`, `goals`, `gamesPlayed`, `wins`, `draws`, `losses`, `rating`, `photo`, `assists`, `saves`, `mvp`) VALUES
(35602859, 'IkRoMchIk_75', 'IkRoMchIk_75', 0, 6, 3, 0, 3, '4.00', 'IkRoMchIk_75.png', 0, 0, 0),
(117470117, 'Pavel Chizhov', 'PChizhov87', 5, 18, 9, 3, 6, '16.80', 'PChizhov87.png', 0, 0, 0),
(124043602, 'Sergey', 'KhroSe', 3, 80, 28, 25, 27, '33.90', 'KhroSe.png', 0, 0, 0),
(128005229, 'Sergey Deshevoy', 'Pedro_Barb0sa', 6, 34, 10, 11, 13, '13.20', 'Pedro_Barb0sa.png', 0, 0, 0),
(137986649, 'Kirill K', 'Xpycts', 0, 6, 2, 4, 0, '6.00', 'Xpycts.png', 0, 0, 0),
(160187428, 'Илья Гаврилов', 'Gavrilovram', 24, 36, 21, 9, 6, '50.00', 'Gavrilov.png', 0, 0, 0),
(167980324, 'Alexey Neponyatno', 'alexey_neponyatno', 1, 5, 1, 0, 4, '0.00', 'default.jpg', 0, 0, 0),
(199244698, 'HUNTER', 'HUNTER100983', 1, 16, 4, 4, 8, '1.80', 'HUNTER100983.png', 0, 0, 0),
(209066005, 'Святослав Спирин', 'svyatoslavspirin', 22, 83, 39, 21, 23, '64.50', 'svyatoslavspirin.png', 0, 0, 0),
(218953069, 'Petr Pushkarev', 'iLikeTP', 1, 32, 7, 6, 19, '7.70', 'iLikeTP.png', 0, 0, 0),
(283390860, 'GDI', '@unknown', 1, 7, 4, 2, 1, '13.00', 'gdi.png', 0, 0, 0),
(284168174, 'KV-19', '@unknown', 5, 28, 9, 6, 13, '10.50', 'KV-19.png', 0, 0, 0),
(311061398, 'Тримонов Николай', 'N_Trimonov', 3, 19, 5, 5, 9, '5.50', 'N_Trimonov.png', 0, 0, 0),
(312571900, 'Павел Солнцев', 'pavelsolnsev', 81, 218, 92, 72, 71, '120.10', 'pavelsolnsev.png', 9, 1, 1),
(322438954, 'Nikita', 'iamnotnikita', 69, 150, 55, 44, 51, '88.50', 'iamnotnikita.png', 0, 0, 0),
(332067230, 'Игорь Ковязин', 'mi28nm', 1, 12, 2, 4, 6, '1.50', 'mi28nm.png', 0, 0, 0),
(362889423, 'Павел Штепа', 'Paxan4', 0, 10, 1, 3, 6, '2.90', 'Paxan4.png', 0, 9, 0),
(364585741, 'Иван Семенников', 'seivrtd', 90, 171, 77, 53, 41, '121.30', 'seivrtd.png', 2, 0, 1),
(365485366, 'ArsenAr89', 'ArsenAr89', 2, 14, 6, 7, 1, '18.10', 'ArsenAr89.png', 0, 0, 0),
(371804756, 'Александр', 'ridestreet', 1, 31, 9, 10, 12, '19.50', 'ridestreet.png', 0, 0, 0),
(388748352, 'Максим М', 'mbodunov078', 1, 1, 1, 0, 0, '2.30', 'mbodunov.png', 0, 0, 0),
(407842790, 'ᑎᗣᗯᏦᗣ', 'HA_3AKATE_KAPbEPbI', 12, 6, 1, 1, 4, '4.00', 'zakat.png', 0, 0, 0),
(443678292, 'Влад', 'vl_l24', 16, 99, 29, 39, 31, '56.90', 'vl_l24.png', 0, 0, 0),
(476398393, 'Виктор Безруков', 'BezrukovViktor', 0, 6, 1, 2, 3, '0.00', 'BezrukovViktor.png', 0, 0, 0),
(479874387, 'Антон Неуймин', 'KroxaAn', 14, 123, 37, 26, 60, '24.80', 'KroxaAn.png', 0, 0, 0),
(487389735, 'Сергей Lazio', '@unknown', 0, 6, 4, 1, 1, '11.50', 'Lazio.png', 0, 0, 0),
(490920700, 'Evgenii', 'vpapalame', 5, 48, 13, 18, 17, '30.00', 'vpapalame.png', 0, 0, 0),
(494481539, 'Artem Rodin', 'RodnoyAR', 7, 22, 6, 6, 10, '7.70', 'RodnoyAR.png', 0, 0, 0),
(496145816, 'Андрей Корунов', 'ankorn1694', 2, 6, 1, 2, 3, '1.50', 'ankorn1694.png', 0, 0, 0),
(510785800, 'Konstantin Chekanov', 'KonstantinChekanov', 10, 57, 14, 20, 22, '23.00', 'KonstantinChekanov.png', 0, 0, 0),
(520274143, 'Pavel Lonshchakov', '@unknown', 10, 35, 11, 9, 15, '16.60', 'Lonshchakov.png', 0, 0, 0),
(528010018, 'Vyn Lavanda', 'VynLavanda', 0, 15, 0, 3, 12, '0.00', 'VynLavanda.png', 0, 0, 0),
(554229380, 'Владислав', 'Perunov_Vladislav', 3, 24, 13, 6, 5, '27.90', 'Perunov_Vladislav.png', 0, 0, 0),
(576639141, 'Алексей.', 'AlexeiD2025', 12, 58, 32, 17, 9, '73.20', 'AlexeiD2025.png', 11, 0, 0),
(581205048, 'Ravil\' Ravil\'', '@unknown', 7, 89, 39, 23, 27, '64.50', 'Ravil.png', 0, 8, 0),
(592463599, 'Андрей', 'Lu4nikk', 0, 18, 6, 3, 9, '5.00', 'andr.png', 0, 0, 0),
(593315869, 'Владимир Козлов', 'kozzzlov', 0, 30, 8, 11, 11, '12.00', 'kozzzlov.png', 0, 0, 0),
(604421340, 'я глеб(', 'gdemoi17let', 5, 19, 7, 5, 7, '18.00', 'gdemoi17let.png', 0, 0, 0),
(610306891, 'Иван', '@unknown', 0, 5, 5, 0, 0, '10.00', 'ivan.png', 0, 0, 0),
(683510986, 'Филипп', 'filipps1', 13, 91, 30, 37, 24, '56.80', 'filipps1.png', 0, 0, 0),
(698065993, 'Diego Armando', 'frankie_dux', 0, 8, 4, 4, 0, '10.00', 'frankie_dux.png', 0, 0, 0),
(701324339, 'Антон Данилов', 'toxa1392777', 7, 21, 9, 5, 7, '20.20', 'toxa1392777.png', 0, 0, 0),
(710905774, 'And Saf', '@unknown', 2, 23, 7, 10, 6, '12.20', 'AndSaf.png', 0, 0, 0),
(713489685, 'Алексей', 'alexey19m', 0, 6, 4, 1, 1, '11.50', 'alexe19m.png', 0, 0, 0),
(717617605, 'Абдулатип', 'Abdulatip44', 17, 102, 36, 30, 36, '52.70', 'Abdulatip44.png', 1, 3, 0),
(721604540, 'Viktor DoBronx', 'Iatinose', 0, 14, 3, 3, 8, '2.00', 'Iatinose.png', 0, 0, 0),
(723505634, 'Владислав Брижатый', 'Mirinian', 30, 173, 50, 54, 69, '60.50', 'mirinian.png', 0, 0, 0),
(750675663, 'Дима', 'dergaev94', 7, 43, 22, 12, 9, '46.70', 'dergaev.png', 0, 2, 0),
(756531984, 'Константин Кирсанов', 'toshnotik666', 12, 146, 54, 42, 50, '68.30', 'toshnotik666.png', 1, 3, 0),
(778775414, 'Павел Ряховский', 'ryakhovskyp', 0, 13, 8, 2, 3, '21.50', 'ryakhovskyp.png', 0, 0, 0),
(784470577, 'Aleksandr Galanov', 'galanovfitness', 2, 6, 2, 1, 3, '3.50', 'galanovfitness.png', 0, 0, 0),
(795473808, 'delay_kpacubo', 'delay_kpacubo', 24, 48, 27, 12, 9, '60.50', 'kpacubo.png', 0, 0, 0),
(803612820, 'Иван Трифонов', 'deltaivan', 15, 223, 76, 66, 81, '83.20', 'deltaivan.png', 0, 0, 0),
(804693453, 'Nikcha', 'Nikcha228', 0, 15, 0, 3, 12, '0.00', 'Nikcha228.png', 0, 0, 0),
(809096910, 'В Е', 'valenokkk09', 0, 12, 2, 4, 6, '0.00', 'valenokkk09.png', 0, 0, 0),
(813827551, 'Михаил Кошелев', '@unknown', 7, 58, 19, 19, 20, '41.60', 'Mikhail.png', 0, 0, 0),
(817333788, 'Константин Орлов', 'freza01', 1, 6, 2, 4, 0, '6.50', 'freza01.png', 0, 0, 0),
(826253475, 'Georgiy', 'GoshaSc', 0, 13, 2, 3, 8, '0.00', 'GoshaSc.png', 0, 0, 0),
(867431728, 'Alexander Ivanov', 'Aleksandr93', 0, 12, 1, 4, 7, '0.00', 'Aleksandr93.png', 0, 0, 0),
(882862623, 'Youdjen', 'gerop_il', 0, 6, 1, 2, 3, '0.50', 'gerop_il.png', 0, 0, 0),
(888120901, 'دانيلكا', 'R_kirpichik', 3, 8, 3, 2, 3, '6.00', 'R_kirpichik.png', 0, 0, 1),
(905118744, 'Igor Tatarinov', '@unknown', 3, 18, 6, 5, 7, '14.50', 'Tatarinov.png', 0, 0, 0),
(929351490, 'Anton Zakharov', 'fucking1986', 0, 12, 5, 1, 6, '6.00', 'fucking1986.png', 0, 0, 0),
(934131507, 'Vadim', 'Vadimka_brrrr', 17, 83, 28, 26, 29, '32.20', 'Vadimka_brrrr.png', 0, 0, 0),
(960743939, 'Egor', 'legor62', 7, 39, 15, 13, 11, '26.00', 'legor62.png', 0, 0, 0),
(969862042, 'Artem', 'al11114', 18, 104, 34, 31, 39, '55.80', 'al11114.png', 1, 0, 0),
(975739952, 'Руслан', 'AlyevRuslan', 49, 239, 66, 78, 95, '70.80', 'CyJlTaH1117.png', 0, 0, 0),
(991937798, 'Сергей', '@unknown', 11, 38, 16, 9, 13, '28.70', 'sergey.png', 0, 0, 0),
(996357064, 'Александр Силкин', 'silkin_xandr', 8, 25, 4, 14, 7, '11.90', 'silkin_handr.png', 0, 0, 0),
(999543108, 'Igor', 'y0ung_m0on', 21, 104, 45, 27, 32, '67.30', 'igor_oru.png', 0, 0, 0),
(1004719301, 'Кирилл Романов', '@unknown', 7, 66, 21, 29, 16, '49.20', 'romanov.png', 0, 0, 0),
(1013482464, 'Роман Ыы', '@unknown', 0, 8, 0, 5, 3, '0.00', 'roman.png', 0, 0, 0),
(1014712896, 'Артем', '@unknown', 5, 100, 39, 33, 28, '65.60', 'artem.png', 0, 0, 0),
(1017179405, 'NizHgaN', 'NizHgaN', 0, 6, 4, 2, 0, '14.00', 'NizHgaN.png', 0, 0, 0),
(1021231958, 'Ilya Rostyagaylov', 'mr_snak4', 13, 111, 39, 42, 30, '73.80', 'mr_snak4.png', 0, 0, 0),
(1025888549, 'Николай Сапотницкий', 'Spasatel_1731', 1, 6, 3, 0, 3, '3.30', 'Spasatel_1731.png', 0, 0, 0),
(1029330977, 'Даниил Турланов', '@unknown', 33, 112, 52, 31, 29, '101.40', 'tyrlanov.png', 0, 0, 0),
(1061258152, 'Artem Trafimov', 'ArtemTrafimov', 16, 116, 34, 46, 36, '59.30', 'ArtemTrafimov.png', 0, 0, 0),
(1061628918, 'Артем Перегудов', 'Artibai', 0, 7, 3, 1, 3, '3.50', 'Artibai.png', 0, 0, 0),
(1091074082, 'Сергей', 'MS_Leon17', 0, 6, 1, 1, 4, '0.00', 'MS_Leon17.png\r\n', 0, 0, 0),
(1101519104, 'Niki Fedosov', '@unknown', 4, 25, 8, 10, 7, '20.20', 'niki.png', 0, 0, 0),
(1107610545, 'Александр Коротков', 'Crespo199319993', 0, 7, 3, 3, 1, '6.50', 'Crespo199319993.png', 0, 0, 0),
(1133469322, 'Михаил', '@unknown', 8, 104, 42, 33, 29, '74.20', 'mixail.png', 0, 0, 0),
(1171138656, 'Nikita Alexandrovich', 'nikita_a1exandrovich', 33, 123, 33, 30, 60, '23.80', 'nikita.png', 2, 0, 0),
(1190862667, 'Alex', 'Sashok1122', 25, 102, 32, 31, 39, '53.30', 'sashok.png', 2, 0, 0),
(1249681171, '.', 'game_on_manneger', 0, 21, 5, 10, 6, '6.00', 'game_on_manneger.png', 0, 0, 0),
(1293900829, 'senya Avgan', 'SenyaAvgan', 29, 78, 31, 30, 17, '69.00', 'SenyaAvgan.png', 0, 0, 0),
(1333884636, 'Даниил Ильин', 'desantiiago', 1, 10, 4, 4, 2, '8.30', 'desantiiago.png', 0, 0, 0),
(1382503602, 'Изат', 'izi0895', 6, 76, 24, 32, 20, '48.90', 'izi0895.png', 0, 0, 0),
(1441999755, 'D', 'DMITRIY_MSK_V', 0, 8, 2, 5, 1, '9.50', 'DMITRIY_MSK_V.png', 0, 0, 0),
(1461810849, 'Дмитрий', 'taltskov', 1, 6, 2, 1, 3, '3.00', 'taltskov.png', 0, 0, 0),
(1508816489, 'Алексей Прокопчук', 'Alexey_1803', 1, 20, 9, 8, 3, '27.00', 'Alexey_1803.png', 0, 0, 0),
(1590480935, 'Александр', 'Aleksandr_bannik', 1, 9, 5, 2, 2, '8.50', 'Aleksandr_bannik.png', 2, 0, 0),
(1600147426, 'Алекс Алекс', '@unknown', 3, 27, 5, 10, 12, '6.50', 'aleks.png', 0, 0, 0),
(1600372273, 'Сергей Прокопцов', 'Sirgey_zizy', 0, 8, 1, 6, 1, '4.50', 'Sirgey_zizy.png', 0, 0, 0),
(1612213628, 'Ryzholda13', 'rysholda13', 0, 6, 4, 1, 1, '8.50', 'rysholda13.png', 0, 0, 0),
(1642285822, 'Alexsandr', 'Cosmoc52', 2, 34, 12, 10, 12, '14.80', 'Cosmoc52.png', 0, 0, 0),
(1696405923, 'Ivan Ipets', 'IIpets', 19, 69, 26, 21, 22, '41.10', 'IIpets.png', 4, 0, 0),
(1730643738, 'Александр', '@unknown', 50, 93, 33, 23, 35, '57.90', 'aleksandr.png', 4, 0, 0),
(1822122146, 'Stanislav Solomin', '@unknown', 0, 6, 1, 3, 2, '3.00', 'Solomin.png', 0, 0, 0),
(1826935429, 'Владимир', 'BarDblga', 4, 19, 5, 6, 8, '11.00', 'BarDblga.png', 0, 0, 0),
(1827623573, 'Artemii Tikhonov', 'ArtemiiTikhonov', 0, 16, 8, 4, 4, '22.00', 'ArtemiiTikhonov.png', 0, 0, 0),
(1833767374, 'JustahumanMy', 'JustahumanMy', 0, 30, 6, 11, 13, '13.50', 'JustahumanMy.png', 0, 0, 0),
(1965326027, 'Вадик', 'Vadik_69_11', 9, 21, 9, 5, 7, '21.30', 'Vadik.png', 0, 0, 0),
(1974870885, 'Александер', 'alexdugar59', 12, 24, 14, 4, 6, '42.50', 'alexdugar59.png', 0, 0, 0),
(1985685837, 'Андреев Алексей', 'Aleksey_AS_NR', 8, 48, 15, 13, 20, '25.60', 'Aleksey_AS_NR.png', 0, 0, 0),
(2052420208, 'Евгений Швецов', 'evgeniyshvetsov', 26, 105, 34, 26, 45, '50.00', 'evgeniyshvetsov.png', 3, 1, 0),
(5091495530, 'Дмитрий Шмелев', '@unknown', 1, 151, 50, 48, 53, '73.10', 'shmel.png', 0, 0, 0),
(5100975697, 'Виктор Верходанов', 'Verhobanov1983', 3, 20, 9, 6, 5, '16.30', 'Verhobanov1983.png', 0, 0, 0),
(5124368622, 'Max Rakhmankin', 'umeprel', 0, 19, 5, 5, 9, '4.00', 'umeprel.png', 0, 0, 0),
(5308358329, 'Игош', '@unknown', 1, 28, 7, 5, 16, '3.50', 'igosh.png', 0, 0, 0),
(5341453631, 'Тим', 'TimRamen', 2, 14, 5, 2, 7, '3.60', 'TimRamen.png', 0, 0, 0),
(5345759024, 'ru$$ikk', 'Ruslan444ikk', 1, 7, 3, 2, 2, '5.50', 'Ruslan444ikk.png', 0, 0, 0),
(5527376721, 'Дмитрий З', '@unknown', 12, 70, 18, 23, 29, '28.60', 'dmitri.png', 0, 3, 0),
(5576131809, 'Сергей Горшков', 'gos_it_tech', 22, 52, 28, 9, 15, '59.50', 'gos_it_tech.png', 2, 0, 0),
(5743529456, 'Andrey', 'AndrewDfyf2', 0, 31, 9, 13, 9, '17.90', 'AndrewDfyf2.png', 0, 0, 0),
(5878165257, 'Евгений', 'ZhekaFootball', 35, 157, 49, 40, 68, '38.50', 'Evgenkozl.png', 0, 0, 0),
(5905312473, 'SMOOGA', 'SMGGETT', 7, 35, 9, 14, 12, '17.30', 'SMGGETT.png', 0, 0, 0),
(6083918469, 'Never Broke Again', '@unknown', 2, 12, 2, 2, 8, '0.00', 'Never.png', 0, 0, 0),
(6122232732, 'Сергей Ефремов', '@unknown', 0, 6, 0, 3, 3, '0.00', 'default.jpg', 0, 0, 0),
(6190535910, 'Даниил', 'danchik284', 0, 18, 2, 6, 10, '0.00', 'danchik284.png', 0, 0, 0),
(6583256952, 'Vlades 19', '@unknown', 2, 12, 6, 2, 4, '11.40', 'Vlades.png', 0, 0, 0),
(6626440152, 'Вячеслав', 'Slavikbbo', 0, 0, 0, 0, 0, '0.00', 'default.jpg', 0, 0, 0),
(7218237344, 'Анатолий', '@unknown', 1, 7, 3, 1, 3, '6.00', 'anatoli.png', 0, 0, 0),
(7290937174, 'Кодиржон', '@unknown', 0, 24, 12, 6, 6, '25.90', 'kodirjon.png', 1, 2, 0),
(7304592244, 'Сергей Матвеев', '@unknown', 2, 16, 4, 9, 3, '11.10', 'matveev.png', 0, 0, 0),
(7315216925, 'Jorik', '@unknown', 5, 67, 22, 16, 29, '37.80', 'jorik.png', 5, 0, 0),
(7327119445, 'Евгений', 'Jony8603', 0, 8, 2, 2, 4, '2.00', 'Jony8603.png', 0, 0, 0),
(7397709081, 'Rioting', 'vehrbrvk50', 5, 5, 3, 0, 2, '7.50', 'vehrbrvk50.png', 0, 0, 0),
(7412797271, 'Seana', 'faserq', 1, 12, 0, 2, 10, '0.00', 'faserq.png', 0, 0, 0),
(7496871598, 'Александр Акулов', '@unknown', 8, 86, 28, 34, 24, '51.90', 'akylov.png', 0, 0, 0),
(7846120577, 'German Zavgar', 'germanitto', 0, 16, 1, 9, 6, '1.50', 'germanitto.png', 0, 0, 0),
(7860404425, 'Данил', '@unknown', 2, 7, 0, 1, 6, '0.00', 'danil.png', 0, 0, 0),
(7890158700, 'Lexus85 .!.', '@unknown', 0, 11, 3, 4, 4, '4.00', 'default.jpg', 0, 0, 0),
(7988447109, 'Vyacheslav Batrakov', '@unknown', 27, 161, 49, 49, 63, '54.10', 'vacheslav.png', 0, 0, 0),
(8153799766, 'Тима', 't1ma27', 14, 145, 44, 39, 62, '40.90', 't1ma27.png', 2, 0, 0),
(8177622354, 'Ислам Халиков', '@unknown', 105, 228, 99, 65, 73, '131.20', 'islam.png', 5, 0, 0),
(8375849637, 'Денис', '@unknown', 2, 28, 6, 6, 16, '0.00', 'denis.png', 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `teams`
--
-- Creation: Dec 21, 2025 at 10:14 AM
--

DROP TABLE IF EXISTS `teams`;
CREATE TABLE `teams` (
  `id` int NOT NULL,
  `name` varchar(100) NOT NULL,
  `tournament_count` int DEFAULT '0',
  `points` int DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `team_players`
--
-- Creation: Dec 21, 2025 at 10:46 AM
--

DROP TABLE IF EXISTS `team_players`;
CREATE TABLE `team_players` (
  `team_id` int NOT NULL,
  `player_id` bigint UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `players`
--
ALTER TABLE `players`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `teams`
--
ALTER TABLE `teams`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_name` (`name`);

--
-- Indexes for table `team_players`
--
ALTER TABLE `team_players`
  ADD PRIMARY KEY (`team_id`,`player_id`),
  ADD KEY `idx_team_date` (`team_id`),
  ADD KEY `idx_player_date` (`player_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `teams`
--
ALTER TABLE `teams`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `team_players`
--
ALTER TABLE `team_players`
  ADD CONSTRAINT `team_players_ibfk_1` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `team_players_ibfk_2` FOREIGN KEY (`player_id`) REFERENCES `players` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
